## [0.9.8b]

Updated : Tony
Date: 2016-08-08

Fix
- **gPow** used in MK2 only

Changes
-
